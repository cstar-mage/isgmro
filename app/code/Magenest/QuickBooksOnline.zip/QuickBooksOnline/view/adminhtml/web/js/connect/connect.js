define([
    'jquery',
    'intuit.ipp.anywhere'
], function($, app){
    'use strict';
    alert("asnkasjc");
    // intuit.ipp.anywhere.setup({
    //     menuProxy: '<?php echo $block->getMenuUrl();?>',
    //     grantUrl: '<?php echo $block->getGrantUrl();?>'
    // });
});