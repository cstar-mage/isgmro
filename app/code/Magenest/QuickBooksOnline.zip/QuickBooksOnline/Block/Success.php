<?php
/**
 * Copyright © 2017 Magenest. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magenest\QuickBooksOnline\Block;

/**
 * Class Success
 * @package Magenest\QuickBooksOnline\Block
 */
class Success extends \Magento\Framework\View\Element\Template
{

}
