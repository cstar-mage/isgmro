<?php
namespace Magenest\QuickBooksOnline\Logger;

class Logger extends \Monolog\Logger
{
}